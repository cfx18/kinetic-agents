"""Kinetic Agents package component."""
